"""DEPRECATED: async orchestrator module.

This module is retained only as a historical stub for reference and will be
removed in a subsequent cleanup pass (TBD). All new code paths use the
 synchronous orchestrator and run event streaming.

Any imports should be removed; tests no longer reference this file.
"""

__all__: list[str] = []
