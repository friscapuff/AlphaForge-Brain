"""Merge raw validation outputs into enriched artifact detail structure.

Input: validation dict from validation_run_all containing keys:
  permutation, block_bootstrap, monte_carlo_slippage, walk_forward

We normalize to:
{
  'permutation': { 'p_value': float, 'distribution': [...], 'observed': float },
  'block_bootstrap': { 'p_value': float, 'distribution': [...], 'observed': float },
  'monte_carlo_slippage': { 'p_value': float, 'distribution': [...], 'observed': float },
  'walk_forward': { 'folds': [...], 'summary': {...} }
}

Any missing sections produce empty placeholders for determinism.
"""
from __future__ import annotations

from typing import Any

import numpy as np


def _dist_section(src: dict[str, Any] | None) -> dict[str, Any]:
    if not src:
        return {"p_value": None, "distribution": [], "observed": None}
    # Avoid ambiguous truth evaluation on numpy arrays; pull candidates explicitly
    dist_candidate = src.get("distribution")
    if dist_candidate is None:
        dist_candidate = src.get("samples")
    dist = dist_candidate if dist_candidate is not None else []
    if isinstance(dist, np.ndarray):  # convert to list for JSON
        dist_list = dist.tolist()
    else:
        dist_list = list(dist)
    # Normalize any numpy scalar types inside list
    norm_list = []
    for v in dist_list:
        if isinstance(v, (np.generic,)):
            norm_list.append(v.item())
        else:
            norm_list.append(v)
    # observed field may have different names across validators
    observed = src.get("observed") or src.get("observed_mean") or src.get("observed_metric")
    if isinstance(observed, (np.generic,)):
        observed = observed.item()
    return {"p_value": src.get("p_value"), "distribution": norm_list, "observed": observed}


def _walk_forward_section(src: Any) -> dict[str, Any]:
    if not src:
        return {"folds": [], "summary": {}}
    # Validation runner returns a list of fold dicts; handle both list and dict-with-folds
    if isinstance(src, list):
        raw_folds = src
        summary = {}
    elif isinstance(src, dict):
        raw_folds = src.get("folds", [])
        summary = src.get("summary", {})
    else:  # unknown type
        raw_folds = []
        summary = {}
    folds = []
    for f in raw_folds:
        if isinstance(f, dict):
            converted = {}
            for k, v in f.items():
                if hasattr(v, "isoformat"):
                    try:
                        converted[k] = v.isoformat()
                    except Exception:  # pragma: no cover
                        converted[k] = str(v)
                else:
                    converted[k] = v
            folds.append(converted)
    return {"folds": folds, "summary": summary}


def merge_validation(validation: dict[str, Any]) -> dict[str, Any]:
    return {
        "permutation": _dist_section(validation.get("permutation")),
        "block_bootstrap": _dist_section(validation.get("block_bootstrap")),
        "monte_carlo_slippage": _dist_section(validation.get("monte_carlo_slippage")),
        "walk_forward": _walk_forward_section(validation.get("walk_forward")),
    }


__all__ = ["merge_validation"]
