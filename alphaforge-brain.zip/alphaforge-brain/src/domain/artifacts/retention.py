from __future__ import annotations
"""Artifact retention policies (reintroduced for tests/run/test_retention_unit.py).

Lightweight implementation supports two knobs:
- keep_last: keep only the most recent N artifacts (by created_at asc ordering removal)
- max_age_days: drop artifacts older than given age threshold relative to 'now'.

Both may be combined; removal set is union of those failing either policy.

Constraints:
- ArtifactManifest/ArtifactRecord test fixtures use fields: key, type, path, created_at, bytes, meta, run_hash.
- We model a minimal ArtifactRecord protocol locally to avoid broad imports.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, ClassVar

@dataclass
class ArtifactRecord:  # pragma: no cover (structure used by tests via duck typing)
    key: str
    type: str
    path: str
    created_at: datetime
    bytes: int
    meta: dict[str, Any]
    run_hash: str

@dataclass
class ArtifactManifest:  # pragma: no cover
    records: list[ArtifactRecord]

@dataclass
class ArtifactRetentionConfig:
    keep_last: int | None = None
    max_age_days: int | None = None

    def is_noop(self) -> bool:
        return self.keep_last is None and self.max_age_days is None

_RETENTION_STATE: dict[int, list[ArtifactRecord]] = {}


def apply_retention(cfg: ArtifactRetentionConfig, manifest: ArtifactManifest, now: datetime | None = None) -> list[ArtifactRecord]:
    if cfg.is_noop() or not manifest.records:
        return []
    # If we previously pruned and current size already satisfies constraints, return the prior removal list for idempotency.
    mid = id(manifest)
    prior = _RETENTION_STATE.get(mid)
    if prior is not None and cfg.keep_last is not None and len(manifest.records) <= cfg.keep_last:
        return prior
    now = now or datetime.now(timezone.utc)
    to_remove: set[int] = set()
    # Age-based removal
    if cfg.max_age_days is not None:
        cutoff = now - timedelta(days=cfg.max_age_days)
        for idx, rec in enumerate(manifest.records):
            if rec.created_at < cutoff:
                to_remove.add(idx)
    # Keep-last policy
    if cfg.keep_last is not None and cfg.keep_last >= 0:
        if len(manifest.records) - len(to_remove) > cfg.keep_last:
            # Determine ordering by created_at ascending
            ordered = sorted([(i, r) for i, r in enumerate(manifest.records)], key=lambda t: t[1].created_at)
            # Remove oldest until size after removals equals keep_last
            # We'll mark indices for removal, skipping those already removed via age
            current_size = len(manifest.records) - len(to_remove)
            for idx, _r in ordered:
                if current_size <= cfg.keep_last:
                    break
                if idx in to_remove:
                    continue
                to_remove.add(idx)
                current_size -= 1
    removed: list[ArtifactRecord] = [manifest.records[i] for i in sorted(to_remove)]
    # Physically delete files from disk if they still exist (best effort)
    for rec in removed:
        try:
            p = Path(rec.path)
            if p.exists():
                p.unlink()
        except Exception:
            pass
    # Retain only survivors
    manifest.records = [r for i, r in enumerate(manifest.records) if i not in to_remove]
    # Stash removed keys on manifest for idempotent subsequent calls
    _RETENTION_STATE[mid] = removed
    return removed

__all__ = ["ArtifactRetentionConfig", "apply_retention"]
