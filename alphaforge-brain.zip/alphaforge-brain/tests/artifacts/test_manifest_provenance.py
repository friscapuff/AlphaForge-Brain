from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from domain.run.create import InMemoryRunRegistry, create_or_get
from domain.schemas.run_config import RunConfig, IndicatorSpec, StrategySpec, RiskSpec, ExecutionSpec, ValidationSpec


def _config() -> RunConfig:
    return RunConfig(
        symbol="TEST",
        timeframe="1m",
        start="2024-01-01",
        end="2024-01-02",
        indicators=[IndicatorSpec(name="dual_sma", params={"fast": 5, "slow": 12})],
        strategy=StrategySpec(name="dual_sma", params={"short_window": 5, "long_window": 12}),
        risk=RiskSpec(model="fixed_fraction", params={"fraction": 0.1}),
        execution=ExecutionSpec(slippage_bps=1),
        validation=ValidationSpec(),
    )


def test_manifest_contains_provenance_fields(tmp_path: Path) -> None:
    registry = InMemoryRunRegistry()
    cfg = _config()
    run_hash, record, created = create_or_get(cfg, registry, seed=cfg.seed)
    assert created is True
    from domain.artifacts.writer import write_artifacts
    manifest = write_artifacts(run_hash, record, base_path=tmp_path / "artifacts")
    assert manifest.get("data_hash"), "data_hash missing in manifest"
    assert manifest.get("calendar_id"), "calendar_id missing in manifest"
    files = manifest.get("files", [])
    assert any(f.get("name") == "validation.json" for f in files), "validation.json not listed in files"
    # validation.json structure
    vfile = tmp_path / "artifacts" / run_hash / "validation.json"
    content = json.loads(vfile.read_text("utf-8"))
    assert "summary" in content, "validation.json missing summary"
    assert "p_values" in content, "validation.json missing p_values"
    assert isinstance(content["summary"], dict)
    assert isinstance(content["p_values"], dict)
