import json
from pathlib import Path
from typing import Any

import pytest

from domain.artifacts.writer import write_artifacts

class Boom(Exception):
    pass


def test_provenance_fallback_logs(monkeypatch: pytest.MonkeyPatch, tmp_path: Path, caplog: Any, capsys: Any) -> None:
    # Force get_dataset_metadata to raise so fallback path triggers
    monkeypatch.setenv("PYTEST_FORCE_PROVENANCE_FAIL", "1")
    def fake_get_dataset_metadata() -> None:
        raise Boom("no meta")
    monkeypatch.setattr("domain.artifacts.writer.get_dataset_metadata", fake_get_dataset_metadata)

    record: dict[str, Any] = {"summary": {}}
    run_hash = "RUN123"
    base = tmp_path / "runs"
    base.mkdir()
    with caplog.at_level("DEBUG"):
        manifest = write_artifacts(run_hash, record, base)
    captured = capsys.readouterr()
    # Basic assertions
    assert manifest.get("data_hash") and manifest.get("calendar_id") == "SYNTH"
    # Look for structured log substring (structlog may render differently so substring match)
    # structlog may emit via stdlib handler; search full text output
    full_text = caplog.text
    if "writer.provenance.fallback" not in full_text:
        rec_join = " ".join(getattr(r, 'message', '') for r in caplog.records)
        aggregate = " ".join([rec_join, full_text, captured.out, captured.err])
        assert "writer.provenance.fallback" in aggregate
    # Manifest file written
    mf = base / run_hash / "manifest.json"
    assert mf.exists()
    loaded = json.loads(mf.read_text())
    assert loaded.get("data_hash") == manifest["data_hash"]
