from __future__ import annotations

from pathlib import Path
from typing import Any

from domain.run.create import InMemoryRunRegistry, create_or_get
from domain.schemas.run_config import (
    ExecutionSpec,
    IndicatorSpec,
    RiskSpec,
    RunConfig,
    StrategySpec,
    ValidationSpec,
)


def make_config() -> RunConfig:
    return RunConfig(
        symbol="TEST",
        timeframe="1m",
        start="2024-01-01",
        end="2024-01-02",
        indicators=[IndicatorSpec(name="dual_sma", params={"fast":5, "slow":20})],
        strategy=StrategySpec(name="dual_sma", params={}),
        risk=RiskSpec(model="fixed_fraction", params={"fraction":0.1}),
        execution=ExecutionSpec(slippage_bps=1),
        validation=ValidationSpec(  # enable some for validation_detail presence
            permutation={"samples": 8},
            block_bootstrap={"samples": 6, "blocks": 4},
            monte_carlo={"paths": 5},
            walk_forward={"folds": 3},
        ),
        seed=123,
    )


def test_manifest_hashes_present_and_stable(tmp_path: Path) -> None:
    registry = InMemoryRunRegistry()
    cfg = make_config()
    run_hash, record, created = create_or_get(cfg, registry, seed=cfg.seed)
    assert created is True

    # First write into temp artifacts dir
    from domain.artifacts.writer import write_artifacts
    artifacts_base = tmp_path / "artifacts"
    manifest1 = write_artifacts(run_hash, record, base_path=artifacts_base)
    run_dir = artifacts_base / run_hash
    assert run_dir.is_dir()

    # All files listed should have null sha256 until T039 implemented (expected failing assertion now)
    files = manifest1.get("files", [])
    assert files, "manifest contains no files"
    # Expect at least summary.json present
    names = {f["name"] for f in files}
    assert "summary.json" in names

    # After T039 implementation all sha256 must be non-null hex strings (length 64)
    for f in files:
        h = f.get("sha256")
        assert h is not None and isinstance(h, str) and len(h) == 64 and all(c in "0123456789abcdef" for c in h), f"Invalid sha256 for {f['name']}"

    # Idempotent second write
    manifest2 = write_artifacts(run_hash, record, base_path=artifacts_base)
    # Hashes stable and identical manifest on idempotent write
    assert manifest1 == manifest2, "Manifest changed unexpectedly after hashing implementation"
