from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from domain.run.create import InMemoryRunRegistry, create_or_get
from domain.schemas.run_config import (
    ExecutionSpec,
    IndicatorSpec,
    RiskSpec,
    RunConfig,
    StrategySpec,
    ValidationSpec,
)

# NOTE: writer not yet implemented; test will fail on import or assertion

def make_config(seed: int = 123) -> RunConfig:
    return RunConfig(
        symbol="TEST",
        timeframe="1m",
        start="2024-01-01",
        end="2024-01-02",
        indicators=[IndicatorSpec(name="dual_sma", params={"fast": 5, "slow": 20})],
        strategy=StrategySpec(name="dual_sma", params={"short_window": 5, "long_window": 20}),
        risk=RiskSpec(model="fixed_fraction", params={"fraction": 0.1}),
        execution=ExecutionSpec(slippage_bps=1, fee_bps=0.0),
        validation=ValidationSpec(),
        seed=seed,
    )


def test_writer_creates_expected_structure(tmp_path: Path) -> None:
    registry = InMemoryRunRegistry()
    cfg = make_config()
    run_hash, record, created = create_or_get(cfg, registry, seed=cfg.seed)
    assert created is True

    artifacts_base = tmp_path / "artifacts"

    try:
        from domain.artifacts.writer import write_artifacts
    except ImportError as err:
        raise AssertionError("writer module not implemented yet") from err

    manifest = write_artifacts(run_hash, record, base_path=artifacts_base)

    run_dir = artifacts_base / run_hash
    assert run_dir.is_dir(), "Run directory not created"

    summary_file = run_dir / "summary.json"
    metrics_file = run_dir / "metrics.json"
    validation_file = run_dir / "validation.json"

    for f in (summary_file, metrics_file, validation_file):
        assert f.is_file(), f"Expected artifact file missing: {f.name}"
        content = json.loads(f.read_text("utf-8"))
        assert isinstance(content, dict)

    # Basic manifest shape assertions
    assert manifest["run_hash"] == run_hash
    assert "created_at" in manifest
    # ISO8601 minimal check
    datetime.fromisoformat(manifest["created_at"])  # will raise if invalid
    files = manifest.get("files", [])
    names = {f["name"] for f in files}
    assert {"summary.json", "metrics.json", "validation.json"}.issubset(names)
    size_map = {e["name"]: e["size"] for e in files}
    for entry in files:
        # New implementation includes sha256 hash
        assert isinstance(entry.get("sha256"), str) and len(entry["sha256"]) == 64
        assert entry["size"] >= 0
        assert not os.path.isabs(entry["path"])

    # Second call should be idempotent (no size changes, manifest deep equal except maybe created_at new - we allow equality only)
    manifest2 = write_artifacts(run_hash, record, base_path=artifacts_base)
    assert manifest == manifest2, "Manifest changed on second write (should be identical)"
    for entry in manifest2["files"]:
        assert entry["size"] == size_map[entry["name"]]
