from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

from fastapi.testclient import TestClient

from api.app import app

client = TestClient(app)

RUN_PAYLOAD = {
    "start": "2024-01-01",
    "end": "2024-01-03",
    "symbol": "TEST",
    "timeframe": "1m",
    "indicators": [
        {"name": "sma", "params": {"window": 5}},
        {"name": "sma", "params": {"window": 15}},
    ],
    "strategy": {"name": "dual_sma", "params": {"fast": 5, "slow": 15}},
    "risk": {"model": "fixed_fraction", "params": {"fraction": 0.1}},
    "execution": {"mode": "sim", "slippage_bps": 0, "fee_bps": 0, "borrow_cost_bps": 0},
    "validation": {"permutation": {"trials": 5}},
    "seed": 123,
}


def _create_run() -> str:
    r = client.post("/runs", json=RUN_PAYLOAD)
    assert r.status_code in (200, 201)
    run_hash = r.json().get("run_hash")
    assert isinstance(run_hash, str)
    return run_hash


def _manifest(run_hash: str) -> dict[str, Any]:
    path = Path("artifacts") / run_hash / "manifest.json"
    assert path.exists(), f"manifest missing at {path}"
    return cast(dict[str, Any], json.loads(path.read_text("utf-8")))


def test_manifest_hashes_present_and_hex() -> None:
    run_hash = _create_run()
    manifest = _manifest(run_hash)
    files = manifest.get("files", [])
    assert files, "expected files listed"
    for f in files:
        h = f.get("sha256")
        assert isinstance(h, str) and len(h) == 64 and all(c in "0123456789abcdef" for c in h.lower())


def test_manifest_idempotent_same_run_hash_reuse() -> None:
    run_hash = _create_run()
    m1 = _manifest(run_hash)
    # Re-submit identical config (idempotent) -> same run_hash -> manifest unchanged
    r2 = client.post("/runs", json=RUN_PAYLOAD)
    assert r2.status_code in (200, 201)
    run_hash2 = r2.json()["run_hash"]
    assert run_hash2 == run_hash
    m2 = _manifest(run_hash)
    assert m1 == m2


def test_manifest_file_hash_matches_content() -> None:
    run_hash = _create_run()
    manifest = _manifest(run_hash)
    for f in manifest.get("files", []):
        name = f["name"]
        sha = f["sha256"]
        file_path = Path("artifacts") / run_hash / name
        assert file_path.exists()
        import hashlib
        data = file_path.read_bytes()
        calc = hashlib.sha256(data).hexdigest()
        assert calc == sha, f"hash mismatch for {name}"
