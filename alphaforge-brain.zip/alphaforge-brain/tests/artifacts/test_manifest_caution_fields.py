import json
from pathlib import Path

from domain.artifacts.writer import write_artifacts


def test_manifest_includes_caution_fields(tmp_path: Path, monkeypatch):
    # Redirect artifacts root to tmp_path
    import infra.artifacts_root as ar

    def fake_resolve_artifact_root(_):
        return tmp_path

    monkeypatch.setattr(ar, "resolve_artifact_root", fake_resolve_artifact_root)

    run_hash = "h_manifest_caution"
    record = {
        "hash": run_hash,
        "summary": {"metrics": {"sharpe": 1.23}},
        "validation_summary": {},
        "p_values": {},
        "validation_caution": True,
        "validation_caution_metrics": ["permutation"],
        "created_at": 0.0,
    }
    write_artifacts(run_hash, record, tmp_path)
    mpath = tmp_path / run_hash / "manifest.json"
    assert mpath.exists()
    doc = json.loads(mpath.read_text("utf-8"))
    # Fields should be present and correct
    assert doc.get("validation_caution") is True
    assert doc.get("validation_caution_metrics") == ["permutation"]
