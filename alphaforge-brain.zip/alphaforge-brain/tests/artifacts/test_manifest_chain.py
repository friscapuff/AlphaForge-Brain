from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, cast

from domain.run.create import InMemoryRunRegistry, create_or_get
from domain.schemas.run_config import (
    ExecutionSpec,
    IndicatorSpec,
    RiskSpec,
    RunConfig,
    StrategySpec,
)


def _cfg(seed: int, start: str) -> RunConfig:
    return RunConfig(
        symbol="CHAIN",
        timeframe="1m",
        start=start,
        end="2024-01-05",
        indicators=[IndicatorSpec(name="sma", params={"window": 5})],
        strategy=StrategySpec(name="dual_sma", params={"fast": 5, "slow": 15}),
        risk=RiskSpec(model="fixed_fraction", params={"fraction": 0.1}),
        execution=ExecutionSpec(slippage_bps=0),
        seed=seed,
    )


def _manifest(run_hash: str, base: Path) -> dict[str, Any]:
    p = base / run_hash / "manifest.json"
    assert p.exists(), f"missing manifest {p}"
    return cast(dict[str, Any], json.loads(p.read_text("utf-8")))


def test_manifest_chain_links_previous(tmp_path: Path) -> None:
    registry = InMemoryRunRegistry()
    artifacts_base = tmp_path / "artifacts"
    artifacts_base.mkdir()

    # First run (no previous) => chain_prev None
    cfg1 = _cfg(1, "2024-01-01")
    h1, r1, _ = create_or_get(cfg1, registry, seed=cfg1.seed)
    # Re-write artifacts to custom base
    from domain.artifacts.writer import write_artifacts
    m1 = write_artifacts(h1, r1, base_path=artifacts_base)
    assert m1["chain_prev"] is None
    assert m1.get("manifest_hash")

    # Second run => chain_prev should reference canonical hash of first manifest
    cfg2 = _cfg(2, "2024-01-02")
    h2, r2, _ = create_or_get(cfg2, registry, seed=cfg2.seed)
    m2 = write_artifacts(h2, r2, base_path=artifacts_base)
    assert m2["chain_prev"] == m1["manifest_hash"], "second run chain_prev mismatch"

    # Third run => chain_prev references second manifest hash
    cfg3 = _cfg(3, "2024-01-03")
    h3, r3, _ = create_or_get(cfg3, registry, seed=cfg3.seed)
    m3 = write_artifacts(h3, r3, base_path=artifacts_base)
    assert m3["chain_prev"] == m2["manifest_hash"], "third run chain_prev mismatch"

    # Idempotent rewrite doesn't change chain_prev or manifest_hash
    m3b = write_artifacts(h3, r3, base_path=artifacts_base)
    assert m3b == m3

    # Ensure chain forms linear linked list back to None
    chain = [m3, m2, m1]
    assert chain[0]["chain_prev"] == chain[1]["manifest_hash"]
    assert chain[1]["chain_prev"] == chain[2]["manifest_hash"]
    assert chain[2]["chain_prev"] is None
