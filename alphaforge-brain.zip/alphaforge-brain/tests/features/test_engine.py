from datetime import datetime, timezone

import pandas as pd
import pytest

# We expect an indicator registry already exists similar to strategies/indicators used earlier.
# Import the registry and a sample indicator (SMA) used in earlier tasks.
from domain.indicators.registry import indicator_registry
from domain.indicators.sma import SimpleMovingAverage

# The engine (to be implemented) will live at domain/features/engine.py
# and expose a function build_features(df: pd.DataFrame) -> pd.DataFrame
# plus maybe a class FeatureEngine for future extension. For now we just test the functional contract.


@pytest.fixture(scope="module")
def candles_df() -> pd.DataFrame:
    data = {
        "timestamp": [
            datetime(2024, 1, 1, 0, 0, tzinfo=timezone.utc),
            datetime(2024, 1, 1, 0, 1, tzinfo=timezone.utc),
            datetime(2024, 1, 1, 0, 2, tzinfo=timezone.utc),
            datetime(2024, 1, 1, 0, 3, tzinfo=timezone.utc),
            datetime(2024, 1, 1, 0, 4, tzinfo=timezone.utc),
        ],
        "open": [100, 101, 102, 103, 104],
        "high": [101, 102, 103, 104, 105],
        "low": [99, 100, 101, 102, 103],
        "close": [100.5, 101.5, 102.5, 103.5, 104.5],
        "volume": [10, 11, 12, 13, 14],
    }
    return pd.DataFrame(data)


def test_engine_applies_registered_indicators(candles_df: pd.DataFrame) -> None:
    # Ensure SMA indicator is registered. (If registry already populated, re-register is idempotent/no-op.)
    indicator_registry.register(SimpleMovingAverage(window=3))

    from domain.features import (
        engine,
    )  # import deferred until after fixture/registration

    out = engine.build_features(candles_df.copy())

    # Original columns must remain
    for col in ["timestamp", "open", "high", "low", "close", "volume"]:
        assert col in out.columns

    # SMA should have produced a column. Convention assumption: f"SMA_{window}_close"
    assert any(
        c.startswith("SMA_3_close") for c in out.columns
    ), "Expected SMA feature column present"

    # Shape: same number of rows
    assert len(out) == len(candles_df)


def test_engine_duplicate_feature_collision_raises(candles_df: pd.DataFrame) -> None:
    # Register two indicators that intentionally collide in feature naming.
    # We'll simulate by creating two SMA objects with same window and monkeypatching one to collide.
    indicator_registry.register(SimpleMovingAverage(window=2))
    sm2 = SimpleMovingAverage(window=2)

    def forced_feature_columns() -> list[str]:  # forces collision
        return [f"SMA_{sm2.window}_close"]

    sm2.feature_columns = forced_feature_columns  # monkeypatch for collision
    indicator_registry.register(sm2)

    from domain.features import engine

    with pytest.raises(ValueError):
        engine.build_features(candles_df.copy())


def test_engine_deterministic_column_order(candles_df: pd.DataFrame) -> None:
    # Ensure registry does not contain prior collision artifacts
    indicator_registry.clear()
    indicator_registry.register(SimpleMovingAverage(window=3))
    from domain.features import engine

    out1 = engine.build_features(candles_df.copy())
    out2 = engine.build_features(candles_df.copy())

    assert list(out1.columns) == list(
        out2.columns
    ), "Column order must be deterministic"


def test_engine_idempotent_same_input_same_output(candles_df: pd.DataFrame) -> None:
    indicator_registry.clear()
    indicator_registry.register(SimpleMovingAverage(window=4))
    from domain.features import engine

    df_in = candles_df.copy()
    out1 = engine.build_features(df_in)
    out2 = engine.build_features(df_in)

    # Deep equality: values identical including NaNs alignment (use pandas testing helper)
    pd.testing.assert_frame_equal(out1, out2)
