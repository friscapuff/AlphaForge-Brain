import '@testing-library/jest-dom';

// Global test helpers can be added here
